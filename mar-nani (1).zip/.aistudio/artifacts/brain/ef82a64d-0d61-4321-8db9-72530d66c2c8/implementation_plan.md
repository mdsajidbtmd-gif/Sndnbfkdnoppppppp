# Tailor Shop Manager — Loop 3 (Printing: Cutting Slip & Invoice) & Mobile UX Refinement

A comprehensive extension of Tailor Shop Manager delivering physical printing workflows for workshop execution (Cutting Slip) and customer billing (Invoice), paired with a complete UX upgrade across every mobile screen in adherence to the Meridian design constitution.

### User Review & Critical Decisions

> [!IMPORTANT]
> The implementation incorporates all confirmed choices from Phase 1 and the Loop 3 PRD:
> - **Mobile UX Across Every Screen**: All screens (Orders, Delivery, Order Details, Form, Settings, and Print Preview) receive enhanced touch geometry (44px min targets), refined typography, responsive cards, ergonomic bottom sheets, and immediate action buttons.
> - **Dedicated Print Preview**: Cutting Slip and Invoice open in a dedicated preview page featuring **Print**, **Back** (returns to previous context), and a quick-switch button to toggle between Cutting Slip and Invoice for the same order.
> - **Preloaded Shop Branding**: Default settings include "Darzi Tailor Shop", an elegant monogram logo, and standard workshop terms, with live preview in Settings and instant logo image upload/removal.
> - **Paper Sizes (A4 & A5)**: Separate settings for Invoice paper size and Cutting Slip paper size (A4 / A5), dynamically applied via print media queries (`@page { size: A4; }` or `@page { size: A5; }`).
> - **Save-First Rule on Form**: On the New/Edit form, clicking "Print Invoice" or "Cutting Slip" validates and saves the order first before launching the print preview.

---

### 1. Overview & Core Concept

- **What It Does**:
  1. **Cutting Slip (Workshop)**: Generates a clean workshop slip containing order number, order date, delivery date, ribbon, customer details, item quantities, and only the filled-in shirt/pant measurements and notes. Strictly no money or pricing appears anywhere on the slip.
  2. **Invoice (Customer)**: Generates a billing statement featuring the shop logo, shop name, customer info, itemized table with prices and line totals, financial summary (Total, Discount, Advance, Received later payments, and remaining Due), and shop terms. Shows no measurements or workshop statuses.
  3. **Print Triggers**: Accessible via icons on Order cards, bottom buttons on Order Details, save-first buttons on the New/Edit form, and the preview screen itself.
  4. **Mobile Experience**: Elevated layout, typography, and gesture ergonomics across all views.
- **Target Audience / Persona**: Counter masters generating immediate customer receipts, and cutting masters in the back workshop reading clear measurement slips pinned to cloth bundles.
- **Key Value**: Streamlines workshop communication, guarantees that printed slips always match saved database records, and gives customers clear billing transparency.

---

### 2. User Experience & Visual Design

#### Print Layouts (CSS `@media print`)
- **Total Print Isolation**: All navigation headers, floating menus, toasts, and buttons are hidden on print (`@media print { .top-shell, .mobile-head, .print-preview-toolbar, .toast { display: none !important; } }`).
- **Black-and-White Legibility**: High-contrast typography on pure white background, optimized for desktop laser printers and workshop thermal/monochrome printers.
- **Dynamic Paper Sizing**: Injects `@page { size: ${state.settings.invoicePaperSize || 'A4'}; margin: 12mm 15mm; }` ensuring clean single-page fit for standard orders, with automatic multi-page overflow handling for long garment lists.

#### Mobile Design Upgrades Across Every Screen
1. **Orders Screen (Mobile)**:
   - Summary cards redesigned with horizontal snap scrolling, compact stat typography, and one-tap quick filters.
   - Status tabs styled as frictionless pill buttons with counts.
   - Mobile order rows enhanced with direct icon triggers for **Cutting Slip** and **Invoice** alongside the **Pay** and **Status** actions.
2. **Order Details Screen (Mobile)**:
   - Glass action bar updated with primary buttons: **Print Slip**, **Invoice**, and **Edit Order**.
   - Clean payments ledger card showing advance and later cash collections.
3. **New / Edit Form (Mobile)**:
   - Sticky glass footer hosting **Save**, **Print Invoice**, and **Cutting Slip** buttons.
   - Auto-saving before opening print previews.
4. **Delivery Screen (Mobile)**:
   - Compact order cards with prominent **Deliver** buttons and instant customer BD search.
5. **Settings Screen (Mobile & Desktop)**:
   - **Invoice Template Block**: Shop name input, logo file upload with thumbnail preview and Remove button, and editable Terms textarea.
   - **Live Header Preview**: Instant preview card demonstrating how the logo, title, and customer block will print.
   - **Print Paper Size Block**: Independent dropdowns for Invoice Paper Size (A4 / A5) and Cutting Slip Paper Size (A4 / A5).

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Native Browser Printing (`window.print()`) vs. PDF Libraries**
  - *Chosen Approach*: Use pure CSS print stylesheets with `@page` and `window.print()`.
  - *Why*: Instantaneous rendering, zero external dependency bloat, works seamlessly across all desktop browsers, Android, and iOS devices.
- **Decision 2: Save-First Form Flow**
  - *Chosen Approach*: Form print buttons execute the complete validation and order creation/update cycle before routing to print preview.
  - *Why*: Guarantees that no paper leaves the shop with a draft or temporary number; every printed document reflects an official saved order.
- **Decision 3: Image / Logo Storage Strategy**
  - *Chosen Approach*: Store uploaded logo images as compressed Base64 DataURLs in the settings document.
  - *Why*: Operates identically in local preview mode and Firestore without requiring external cloud storage buckets or signed URL generation.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Tailor Shop Manager V3                          │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                      Header Navigation                         │   │
│   │  [TS Brand Mark]   [Orders Pill]  [Settings]   [Delivery] [+New]│   │
│   └────────────────────────────────────────────────────────────────┘   │
│                                   │                                    │
│       ┌───────────────────────────┼────────────────────────────┐      │
│       ▼                           ▼                            ▼      │
│ ┌───────────┐              ┌──────────────┐             ┌───────────┐ │
│ │ Orders    │              │ Print        │             │ Settings  │ │
│ │ Screen    │              │ Preview View │             │ Screen    │ │
│ │           │              │              │             │           │ │
│ │ - Summary │              │ - Slip View  │             │ - Invoice │ │
│ │   Cards   │              │ - Invoice    │             │   Template│ │
│ │ - Tabs    │              │   View       │             │ - Logo    │ │
│ │ - Table / │              │ - Paper Size │             │   Upload  │ │
│ │   Cards   │              │   (A4 / A5)  │             │ - Paper   │ │
│ │ - Slip &  │              │ - [Print]    │             │   Sizes   │ │
│ │   Invoice │              │ - [Switch]   │             │ - Live    │ │
│ │   Icons   │              │ - [Back]     │             │   Preview │ │
│ └─────┬─────┘              └──────┬───────┘             └───────────┘ │
│       │                           │                                   │
│       ▼                           ▼                                   │
│ ┌──────────────────────────────────────────────────────────────────┐  │
│ │                     State & Persistence Layer                    │  │
│ │  - Orders: { id, orderNumber, items, measurements, payments... } │  │
│ │  - Settings: { ..., shopName, logo, terms, paperSizes }          │  │
│ │  - Print routing: state.screen = 'print-slip' | 'print-invoice'  │  │
│ └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

#### Settings Data Model Additions
```ts
interface Settings {
  items: CatalogItem[];
  defaultDiscountType: 'percentage' | 'fixed';
  ribbonValues: number[];
  upcomingDeliveryDays: number;
  // Loop 3 Additions
  shopName: string; // Default: 'Darzi Tailor Shop'
  logo: string; // Base64 data URL or empty
  terms: string; // Default shop terms
  invoicePaperSize: 'A4' | 'A5'; // Default: 'A4'
  cuttingSlipPaperSize: 'A4' | 'A5'; // Default: 'A4'
}
```

---

### Verification & Testing Plan

1. **Automated Compilation**:
   - Run `node --check app.js` and `compile_applet`.
2. **Loop 3 PRD Checklist (Section 11)**:
   - Settings: Verify shop name, logo upload, terms, and live header preview.
   - Open an order -> tap **Invoice**: Confirm logo, shop name, order number, dates, customer info, itemized table with prices, Total, Discount, Advance, Paid amounts, remaining Due, terms, and zero measurements.
   - Tap **Print Slip**: Confirm customer, ribbon, delivery date, item quantities (no prices), only filled-in measurements, notes, and no money figures.
   - Form buttons: Tap **Cutting Slip** on an empty new order -> confirm validation error and no save; fill form -> confirm order is created with the next number and preview opens.
   - Form buttons on edit: Update delivery date, tap **Print Invoice** without saving -> confirm order updates and invoice shows new date.
   - Print preview toolbar: Test **Print** dialog trigger, **Back** navigation to previous screen, and switching between slip and invoice.
   - Paper size settings: Verify switching invoice size to A5 applies A5 page styling.
   - Multi-item paging: Test invoice with 10+ items to verify clean layout with final totals block.
   - Mobile UX audit: Verify touch targets, bottom sheets, and responsive layouts across every mobile view.
   - Verify zero occurrences of the word "optional".
