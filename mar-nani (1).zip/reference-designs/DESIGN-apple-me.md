---
version: alpha
name: Meridian-design-language
description: A premium management-software language. Apple-grade materials and physics (glass layers, springs, tight type) on a tonal white-parchment-white surface stack, with one interactive blue and one measurement orange. Blue is what you can press. Orange is what you should notice. Dense data surfaces on desktop, fluid gestures on mobile, one system.

fonts:
  display: "SF Pro Display, -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif"
  text: "SF Pro Text, -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif"
  mono: "SF Mono, ui-monospace, Menlo, monospace"

colors:
  # neutrals
  ink: "#1d1d1f"
  ink-80: "#333333"
  ink-60: "#6e6e73"
  ink-48: "#7a7a7a"
  on-dark: "#ffffff"
  body-muted: "#cccccc"
  canvas: "#ffffff"
  parchment: "#f5f5f7"
  pearl: "#fafafc"
  hairline: "#e0e0e0"
  divider-soft: "#f0f0f0"
  row-selected: "#f0f0f0"
  tile-1: "#272729"
  tile-2: "#2a2a2c"
  tile-3: "#252527"
  black: "#000000"
  chip: "#d2d2d7"
  # interactive (the only thing that is pressable)
  primary: "#0066cc"
  primary-focus: "#0071e3"
  primary-on-dark: "#2997ff"
  primary-wash: "rgba(0, 102, 204, 0.10)"
  # ember (the only thing that says "look here")
  ember-400: "#ff8b4e"
  ember-500: "#f0561f"
  ember-600: "#e8501a"
  ember-text: "#c2410c"
  ember-tint: "#f9cdb6"
  ember-wash: "rgba(240, 86, 31, 0.10)"
  # semantic (status only, never decoration)
  positive: "#1e7b43"
  positive-dot: "#2f9e55"
  positive-tint: "#e3f4e8"
  negative: "#c62828"
  negative-dot: "#e5484d"
  negative-tint: "#fce9e9"
  caution-dot: "#f2a93b"
  # glass fills
  glass-thin: "rgba(255, 255, 255, 0.55)"
  glass-regular: "rgba(245, 245, 247, 0.72)"
  glass-thick: "rgba(245, 245, 247, 0.70)"
  glass-dark: "rgba(39, 39, 41, 0.72)"
  glass-edge-top: "rgba(255, 255, 255, 0.65)"
  glass-edge-bottom: "rgba(0, 0, 0, 0.06)"
  scrim: "rgba(0, 0, 0, 0.34)"

gradients:
  ember: "linear-gradient(160deg, #ff8b4e 0%, #f0561f 55%, #e8501a 100%)"
  graphite: "linear-gradient(135deg, #3d3d40 0%, #1d1d1f 36%, #0a0a0b 100%)"
  hatch: "repeating-linear-gradient(135deg, #f0561f 0 2px, #f9cdb6 2px 4px)"
  sheen: "linear-gradient(105deg, rgba(255,255,255,0) 34%, rgba(255,255,255,0.11) 44%, rgba(255,255,255,0.02) 50%, rgba(255,255,255,0) 58%)"

typography:
  numeral-xl: { fontFamily: "{fonts.display}", fontSize: 96px, fontWeight: 600, lineHeight: 1, letterSpacing: -0.04em, fontVariantNumeric: tabular-nums }
  numeral-lg: { fontFamily: "{fonts.display}", fontSize: 80px, fontWeight: 600, lineHeight: 1, letterSpacing: -0.035em, fontVariantNumeric: tabular-nums }
  stat-xl:    { fontFamily: "{fonts.display}", fontSize: 40px, fontWeight: 600, lineHeight: 1.1, letterSpacing: -0.03em, fontVariantNumeric: tabular-nums }
  stat-lg:    { fontFamily: "{fonts.display}", fontSize: 32px, fontWeight: 600, lineHeight: 1.1, letterSpacing: -0.025em, fontVariantNumeric: tabular-nums }
  stat-md:    { fontFamily: "{fonts.display}", fontSize: 24px, fontWeight: 600, lineHeight: 1.1, letterSpacing: -0.02em, fontVariantNumeric: tabular-nums }
  display:    { fontFamily: "{fonts.display}", fontSize: 40px, fontWeight: 600, lineHeight: 1.1, letterSpacing: -0.03em }
  title-1:    { fontFamily: "{fonts.display}", fontSize: 28px, fontWeight: 600, lineHeight: 1.14, letterSpacing: -0.02em }
  title-2:    { fontFamily: "{fonts.display}", fontSize: 24px, fontWeight: 600, lineHeight: 1.1, letterSpacing: -0.02em }
  lead:       { fontFamily: "{fonts.display}", fontSize: 21px, fontWeight: 600, lineHeight: 1.19, letterSpacing: -0.01em }
  headline:   { fontFamily: "{fonts.text}", fontSize: 17px, fontWeight: 600, lineHeight: 1.24, letterSpacing: -0.374px }
  body:       { fontFamily: "{fonts.text}", fontSize: 17px, fontWeight: 400, lineHeight: 1.47, letterSpacing: -0.374px }
  caption:    { fontFamily: "{fonts.text}", fontSize: 14px, fontWeight: 400, lineHeight: 1.43, letterSpacing: -0.224px }
  caption-strong: { fontFamily: "{fonts.text}", fontSize: 14px, fontWeight: 600, lineHeight: 1.29, letterSpacing: -0.224px }
  footnote:   { fontFamily: "{fonts.text}", fontSize: 12px, fontWeight: 400, lineHeight: 1.33, letterSpacing: -0.12px }
  label:      { fontFamily: "{fonts.text}", fontSize: 12px, fontWeight: 600, lineHeight: 1, letterSpacing: -0.12px }
  # dense desktop data tier (pointer: fine only)
  data-cell:   { fontFamily: "{fonts.text}", fontSize: 13px, fontWeight: 400, lineHeight: 1.38, letterSpacing: -0.08px, fontVariantNumeric: tabular-nums }
  data-strong: { fontFamily: "{fonts.text}", fontSize: 13px, fontWeight: 600, lineHeight: 1.38, letterSpacing: -0.08px, fontVariantNumeric: tabular-nums }
  data-head:   { fontFamily: "{fonts.text}", fontSize: 12px, fontWeight: 600, lineHeight: 1.33, letterSpacing: -0.12px }

rounded:
  xs: 5px
  sm: 8px
  md: 12px
  tray: 16px
  lg: 18px
  xl: 24px
  xxl: 28px
  sheet: 38px
  device: 48px
  pill: 9999px

spacing:
  xxs: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 20px
  xl: 24px
  xxl: 32px
  xxxl: 48px
  section: 80px

shadows:
  product: "rgba(0, 0, 0, 0.22) 3px 5px 30px 0"
  float: "0 8px 32px rgba(0, 0, 0, 0.10)"
  sheet: "0 -10px 40px rgba(0, 0, 0, 0.14)"
  window: "0 24px 64px rgba(0, 0, 0, 0.22)"
  rim-dark: "inset 0 0 0 1px rgba(255,255,255,0.12), inset 0 1px 0 rgba(255,255,255,0.28)"

blur:
  thin: "blur(20px) saturate(180%)"
  regular: "blur(26px) saturate(180%)"
  thick: "blur(28px) saturate(190%)"
  thick-expanded: "blur(44px) saturate(190%)"

motion:
  spring-default: { damping: 1.0, response: 0.35 }
  spring-momentum: { damping: 0.8, response: 0.3 }
  spring-tilt: { damping: 1.0, response: 0.25 }
  press-pill: 0.95
  press-card: 0.97
  press-key: 0.92
  press-duration: 100ms
  drag-hysteresis: 8px
  velocity-window: 120ms
  decel-rate: 0.998

components:
  button-primary:    { backgroundColor: "{colors.primary}", textColor: "{colors.on-dark}", typography: "{typography.body}", rounded: "{rounded.pill}", padding: "11px 22px", height: 44px }
  button-ghost:      { backgroundColor: transparent, textColor: "{colors.primary}", border: "1px solid {colors.primary}", rounded: "{rounded.pill}", padding: "11px 22px", height: 44px }
  button-utility:    { backgroundColor: "{colors.ink}", textColor: "{colors.on-dark}", typography: "{typography.caption}", rounded: "{rounded.sm}", padding: "8px 15px", height: 32px }
  button-tray:       { backgroundColor: "{colors.parchment}", textColor: "{colors.ink}", typography: "{typography.caption-strong}", rounded: "{rounded.pill}", padding: "11px 20px", height: 44px }
  button-icon-glass: { backgroundColor: "{colors.glass-thin}", textColor: "{colors.ink}", rounded: "{rounded.pill}", size: 44px }
  chip-filter:       { backgroundColor: "{colors.canvas}", textColor: "{colors.ink}", typography: "{typography.caption}", border: "1px solid {colors.hairline}", rounded: "{rounded.pill}", padding: "12px 16px", height: 44px }
  chip-filter-on:    { border: "2px solid {colors.primary-focus}", rounded: "{rounded.pill}" }
  delta-chip:        { typography: "{typography.label}", rounded: "{rounded.pill}", padding: "4px 8px", height: 22px }
  shell:             { backgroundColor: "{colors.parchment}" }
  panel:             { backgroundColor: "{colors.canvas}", rounded: "{rounded.xl}", padding: "24px" }
  panel-mobile:      { backgroundColor: "{colors.canvas}", rounded: "{rounded.xxl}", padding: "8px" }
  tray:              { backgroundColor: "{colors.parchment}", rounded: "{rounded.tray}", padding: "8px" }
  stat-tile:         { backgroundColor: "{colors.parchment}", textColor: "{colors.ink}", rounded: "{rounded.lg}", padding: "16px" }
  stat-tile-hero:    { backgroundColor: "{gradients.ember}", textColor: "{colors.on-dark}", rounded: "{rounded.lg}", padding: "16px" }
  object-card:       { backgroundColor: "{gradients.graphite}", textColor: "{colors.on-dark}", rounded: "{rounded.xxl}", shadow: "{shadows.product}" }
  promo-card:        { backgroundColor: "{colors.tile-1}", textColor: "{colors.on-dark}", rounded: "{rounded.xl}", padding: "16px" }
  glass-bar:         { backgroundColor: "{colors.glass-regular}", backdropFilter: "{blur.regular}", border: "1px solid {colors.glass-edge-top}" }
  glass-sheet:       { backgroundColor: "{colors.glass-thick}", backdropFilter: "{blur.thick}", rounded: "{rounded.sheet}", shadow: "{shadows.sheet}" }
  glass-toast:       { backgroundColor: "{colors.glass-regular}", backdropFilter: "{blur.thick}", rounded: "{rounded.pill}", height: 56px, shadow: "{shadows.float}" }
  tab-bar:           { backgroundColor: "{colors.glass-regular}", backdropFilter: "{blur.regular}", rounded: "{rounded.pill}", height: 64px, shadow: "{shadows.float}" }
  nav-item-active:   { backgroundColor: "{colors.ink}", textColor: "{colors.on-dark}", rounded: "{rounded.pill}", height: 40px }
  search-input:      { backgroundColor: "{colors.canvas}", textColor: "{colors.ink}", typography: "{typography.body}", border: "1px solid rgba(0,0,0,0.08)", rounded: "{rounded.pill}", padding: "12px 20px", height: 44px }
  table-head:        { backgroundColor: "{colors.parchment}", textColor: "{colors.ink-80}", typography: "{typography.data-head}", height: 40px }
  table-row:         { backgroundColor: "{colors.canvas}", textColor: "{colors.ink}", typography: "{typography.data-cell}", height: 48px, border-bottom: "1px solid {colors.divider-soft}" }
---

# Meridian Design Language

> One sentence to hold in your head: **white panels on a parchment shell, one ink for text, one blue for things you press, one orange for the number that matters, and glass only where something floats.**

This file is the brand book. An AI builder or a developer should be able to build any screen of a management product from it alone, without asking for a picture. Meridian is a working name. Replace it freely, the language does not depend on it.

## How to read this file

- **This file is the brand: what things look like.** Its companion, `DESIGN-THEORY.md`, is the decision theory: which layout, hierarchy, container and UI pattern to choose for any website or app. Upload both together. When they disagree on a value, this file wins. When they disagree on a decision, the theory wins. Sections 4 and 8 here describe the management-product shell and its components. For any other product type (landing page, editorial, form, settings, catalog, canvas), use the archetypes in the theory file with the tokens in this one.
- **Section order is priority order.** If two rules conflict, the earlier section wins.
- **"Built" and "Specified".** Every component below is marked. *Built* means it exists in the three phone screens (Today, Log time, Inbox) and the first desktop dashboard, and the values here are read from that code. *Specified* means this guide defines it for the desktop management layer and the orange accent, but it has not been drawn yet. Treat both as binding.
- **Never inline a hex, a radius or a shadow.** Use the token. If a token is missing, add one here first.

## Provenance

Three sources, merged with a clear order of authority:

1. **Apple design analysis (DESIGN.md) and the apple-design skill** are the foundation: the neutral ink and parchment palette, the single interactive blue, SF Pro tracking, the 17px reading size, pill and utility radii, one-product-shadow discipline, the 0.95 press, and every motion and material rule (springs, interruptibility, momentum, rubber banding, translucent layers, reduced motion).
2. **Finexy style reference (orange)** contributes structure for data-heavy screens: white panels on a gray shell, nested gray trays, floating pill navigation, one gradient hero tile, hatched chart bars, dot plus text statuses, and tonal stacking instead of shadow.
3. **A premium wallet mockup** contributed the mobile treatment: very large numerals, a glossy dark object, soft rounded rows, small badges on avatars.

Where Finexy and Apple disagree, Apple wins on color roles, type and motion. Finexy wins on page structure and density.

---

## 1. What makes it feel premium

Colors alone never make a design premium. These ten construction rules do. Check every screen against them.

1. **Tone, not lines.** Separation comes from surface steps (shell, panel, tray, tile). Borders are rare hairlines, never boxes around boxes.
2. **One big number per screen.** A single large tabular numeral gives the page a focal point. Everything else is quiet.
3. **Concentric radii.** An inner radius equals the outer radius minus the gap between them. Nothing has two unrelated curves touching.
4. **Tight display type, open body type.** Large text is tracked negative, body text reads at 17px with 1.47 leading. Never one letter-spacing for all sizes.
5. **Two weights.** 400 and 600. No 500, no 700. Weight 300 appears only in large airy leads.
6. **A real material, used sparingly.** Glass appears on layers that float above content, never on content itself. Light glass is never stacked on light glass.
7. **Shadows are rationed.** Three shadow recipes exist in the whole system (section 6). Panels, tiles and buttons never have one.
8. **Color is rationed.** Blue is for pressing. Orange is for noticing. Green, red and amber are for status only. Everything else is neutral.
9. **Everything answers touch immediately.** Press feedback begins on pointer down, tracks the finger 1:1 during drags, and every animation can be grabbed and reversed mid-flight.
10. **Detail you can defend.** Every spacing, radius and duration is a token. Nothing is random.

---

## 2. Colors

### 2.1 Roles at a glance

| Layer | Token | Hex | Used for |
|---|---|---|---|
| Shell | `parchment` | #f5f5f7 | Page background behind panels. Also the fill of trays and neutral stat tiles inside white panels. |
| Panel | `canvas` | #ffffff | Panels, list cards, table rows, search input, filter chips. |
| Selected row | `row-selected` | #f0f0f0 | Selected or hovered table row. |
| Hairline | `hairline` | #e0e0e0 | The only border color. 1px, on white elements that need definition against white. |
| Divider | `divider-soft` | #f0f0f0 | Row dividers inside panels. Inset from the left edge on list rows. |
| Ink | `ink` | #1d1d1f | All primary text, key numerals, the active nav pill, dark utility button. Never pure black text. |
| Secondary text | `ink-80` | #333333 | Secondary copy on light. |
| Tertiary text | `ink-60` | #6e6e73 | Captions, axis ticks, table headers, timestamps. 5.1:1 on white. |
| Disabled | `ink-48` | #7a7a7a | Disabled labels and legal fine print only. Fails 4.5:1 for small text, so never for live content. |
| Dark surfaces | `tile-1/2/3`, `black` | #272729 / #2a2a2c / #252527 / #000 | Promo cards, dark sections, the global nav. Pure black only for true void. |

### 2.2 The two accents

| Accent | Token | Hex | Meaning | Rule |
|---|---|---|---|---|
| **Action Blue** | `primary` | #0066cc | "You can press this." | Every link, primary button, text button, focus ring root, selected filter ring. Nothing non-interactive is ever blue. |
| Focus Blue | `primary-focus` | #0071e3 | Keyboard focus and selected-chip ring. | 2px outline, 2px offset. |
| Sky Blue | `primary-on-dark` | #2997ff | Links and active glyphs on dark surfaces only. | Never on light. |
| **Ember** | `ember-500` | #f0561f | "Notice this." | Hero stat tile, capacity and progress fills, the hatched part of a chart, the brand mark, the single highlighted series. Never on a button, never on a link. |
| Ember gradient | `gradients.ember` | #ff8b4e to #f0561f to #e8501a | The one hero stat tile, and the ember object card. | Maximum one per viewport. |
| Ember text | `ember-text` | #c2410c | Ember-colored text on light. | 5.2:1 on white. Use this, not `ember-500`, for any small orange text. |
| Ember wash | `ember-wash` | 10% ember | Soft pill background for orange labels such as "At capacity". | Text on it is `ember-text`. |

**The split that keeps it premium:** blue and orange never touch in the same component. A blue button may sit next to an ember tile, but an ember tile never contains a blue link. Inside an ember tile, actions are white-on-translucent.

### 2.3 Semantic status colors

Status colors describe state only. They never decorate. Each has a text color that passes contrast, a dot color that is brighter, and a tint for chips.

| State | Dot | Text | Tint | Meaning in a management product |
|---|---|---|---|---|
| Positive | `positive-dot` #2f9e55 | `positive` #1e7b43 | `positive-tint` #e3f4e8 | On track, completed, approved, delta up where up is good. |
| Negative | `negative-dot` #e5484d | `negative` #c62828 | `negative-tint` #fce9e9 | At risk, overdue, declined, delta down where down is bad. |
| Caution | `caution-dot` #f2a93b | Ink (label stays ink) | none | In progress, pending, needs review. Dot only. |
| Neutral | `ink-60` | `ink-60` | `parchment` | Draft, archived, not started. |

Direction is not value. A cost going down is positive and green even though the arrow points down. Always compute the chip color from "good or bad", then pick the arrow from the direction.

### 2.4 Color budget

On any single screen, aim for roughly:

- **70%** neutral surfaces (shell, panels, trays)
- **20%** ink (text, numerals, active nav, solid chart bars)
- **7%** blue (buttons, links, selected filter)
- **3%** ember (one hero tile or one highlighted fill, plus the brand mark)
- Status colors only as small dots, chips and delta text.

If ember exceeds about 5% of the screen, remove some. Its power comes from scarcity.

### 2.5 Contrast contract

All pairs below are verified. Nothing below 4.5:1 for text under 24px, 3:1 for large text and UI shapes.

| Foreground | Background | Ratio | Allowed for |
|---|---|---|---|
| Ink #1d1d1f | White | 16.8:1 | All text |
| Ink-60 #6e6e73 | White / Parchment | 5.1 / 4.7 | Captions, headers |
| Primary #0066cc | White | 5.6:1 | Links, ghost buttons |
| White | Primary #0066cc | 5.6:1 | Primary button label |
| Ember-text #c2410c | White / Parchment | 5.2 / 4.8 | Small orange text |
| White | Ember #f0561f | 3.5:1 | Large numerals only (24px and up, weight 600) |
| Ink | Ember #f0561f | 4.9:1 | Small labels placed on the ember tile |
| Positive #1e7b43 | Positive tint | 4.6:1 | Delta chips |
| Negative #c62828 | Negative tint | 4.8:1 | Delta chips |

On the ember tile: numerals are white at 32px or larger. Labels and captions under 24px are Ink, not white.

---

## 3. Typography

### 3.1 Families

- **Display** (SF Pro Display, then Inter) at 20px and up. **Text** (SF Pro Text, then Inter) below 20px. On Apple devices `system-ui` resolves to the real SF Pro with optical sizing.
- Off Apple platforms use **Inter variable** with `font-feature-settings: "ss03"`. Subtract `0.01em` of tracking at display sizes and `0.03` of line height at body sizes to match SF Pro.
- Money, dates, percentages, counts and table figures always use `font-variant-numeric: tabular-nums`.
- Weights are **400 and 600**. Weight 300 appears only in airy leads of 24px and up. Never 500, never 700.

### 3.2 Ladder

| Token | Size / Line | Weight | Tracking | Use |
|---|---|---|---|---|
| `numeral-xl` | 96 / 1 | 600 | -0.04em | The single amount on an entry screen (keypad). One per screen. |
| `numeral-lg` | 80 / 1 | 600 | -0.035em | The hero metric at the top of a mobile screen. |
| `stat-xl` | 40 / 1.1 | 600 | -0.03em | Hero stat tile value, desktop. |
| `stat-lg` | 32 / 1.1 | 600 | -0.025em | Standard stat tile value. |
| `stat-md` | 24 / 1.1 | 600 | -0.02em | Compact stat (inside tables, wallet rows). |
| `display` | 40 / 1.1 | 600 | -0.03em | Large page title (mobile), page greeting (desktop). |
| `title-1` | 28 / 1.14 | 600 | -0.02em | Sheet and section heading. |
| `title-2` | 24 / 1.1 | 600 | -0.02em | Hero card title. |
| `lead` | 21 / 1.19 | 600 | -0.01em | Panel title on desktop, sub-nav category. |
| `headline` | 17 / 1.24 | 600 | -0.374px | Row titles, card titles, strong inline. |
| `body` | 17 / 1.47 | 400 | -0.374px | Paragraphs and descriptions. Never below 1.47 leading. |
| `caption` | 14 / 1.43 | 400 | -0.224px | Row meta, secondary text, chips. |
| `caption-strong` | 14 / 1.29 | 600 | -0.224px | Emphasized captions, section labels. |
| `footnote` | 12 / 1.33 | 400 | -0.12px | Legal, timestamps in dense lists. |
| `label` | 12 / 1 | 600 | -0.12px | Tab labels, delta chips, badges. |
| `data-cell` | 13 / 1.38 | 400 | -0.08px | **Dense tier.** Table cells. |
| `data-strong` | 13 / 1.38 | 600 | -0.08px | **Dense tier.** Table key column, totals. |
| `data-head` | 12 / 1.33 | 600 | -0.12px | **Dense tier.** Table headers, sentence case, no uppercase. |

### 3.3 Two density modes

| | Comfortable (default) | Dense (desktop data) |
|---|---|---|
| Where | Mobile everything. Desktop dashboards, overview, detail headers. | Desktop tables, logs, resource grids, admin lists. |
| Body | 17px | 13px |
| Row height | 64–76px | 44–52px |
| Hit target | 44px | 36px minimum, only under `@media (pointer: fine)` |
| Trigger | Default | Opt in per component with `data-density="dense"`. Never mix in one table. |

Dense mode changes size and row height only. Color, radii, weight and tracking rules stay identical.

### 3.4 Type rules

- Large type is tighter, small type is looser. Display is tracked negative. 12px and below never gets negative tracking beyond -0.12px.
- Hierarchy is weight plus size plus gray value together. Do not rely on size alone.
- Sentence case everywhere. No all caps labels. No label above a field that merely repeats its placeholder.
- Size text in `rem` so user text-size settings scale the layout. Spacing scales with it.

---

## 4. Layout and spacing

### 4.1 Spacing scale (4px base)

`4 · 8 · 12 · 16 · 20 · 24 · 32 · 48 · 80`. Structure snaps to 8, 12, 16, 20, 24. Use 4 only inside tight type pairs. Use 80 only between marketing-style sections.

| Gap | Value |
|---|---|
| Between panels | 20px |
| Between tiles inside a panel | 12px |
| Panel padding (desktop) | 24px |
| Panel padding (mobile list card) | 8px outer, rows carry 12–16px |
| Tray padding | 8px |
| Tile padding | 16px |
| Page gutter | 32px at 1280 and up, 24px at 834–1279, 20px on phones |
| Space above a page title | at least 24px below the top bar |

Nearest content to a hero object (card, chart, number) is at least 24px away. Whitespace is the pedestal.

### 4.2 Desktop shell (Specified)

```
┌────────────┬──────────────────────────────────────────────┐
│ Sidebar    │ Glass top bar  (56px, sticky, blurs content) │
│ 264px      ├──────────────────────────────────────────────┤
│ (72 when   │ Page title row: greeting + actions           │
│ collapsed) │ 12-column grid, 20px gutters, max 1440px     │
│            │ Row 1: hero stat + stat grid + main chart    │
│ parchment  │ Row 2: list panel + wide data table          │
└────────────┴──────────────────────────────────────────────┘
```

- **Shell** `parchment`. **Sidebar** sits directly on the shell with no panel. Items are 40px tall. The active item is an Ink pill with a white label. Inactive items are `ink-80`. A section label (`caption-strong`, `ink-60`) separates groups.
- **Top bar** is a glass bar, 56px, sticky. It starts transparent and gains blur and a hairline as content scrolls under it (see 7.4). It holds search (left or center), global actions, notifications and the profile capsule.
- **Content** is a 12-column grid. Panels span 3, 4, 6, 8 or 12 columns. Panels in a row share top and bottom edges.
- Between 834 and 1023px the sidebar collapses to icons (72px). Below 834px it becomes the glass tab bar, with four primary destinations and the rest under a "More" or profile menu.

### 4.3 Mobile shell (Built)

- **Canvas** 390 × 844 reference. Content scrolls under a transparent top bar that turns to glass after 48px of scroll.
- **Large title** collapses into a centered small title in the bar as you scroll (opacity and scale tied to scroll, 0 to 56px).
- **Tab bar** is a floating glass capsule, 64px tall, 20px from the sides, 22px from the bottom, with a sliding white indicator. It slides away and fades out when a sheet rises over it.
- **Primary sheet** is a glass sheet with three snap heights (peek, half, full).

### 4.4 Breakpoints

| Name | Width | Changes |
|---|---|---|
| Small phone | up to 419 | Display type drops to 28px. One column. |
| Phone | 420–640 | Display 34px. Panels full width. |
| Large phone | 641–735 | Section padding tightens 80 to 48. |
| Tablet portrait | 736–833 | Sidebar becomes tab bar. |
| Tablet landscape | 834–1023 | Sidebar collapsed to 72px. 12 columns become 8. |
| Desktop | 1024–1440 | Full layout, 12 columns. |
| Wide | 1441 and up | Content locks at 1440. Margins absorb the rest. |

Stat grids collapse 4 → 2 → 1 columns at 1068, 834, 640. Tables become card lists below 640 (each row a list card with the status as a dot beside the title).

---

## 5. Shape

### 5.1 Radius scale

| Token | px | Use |
|---|---|---|
| `xs` | 5 | Inline link chips (rare). |
| `sm` | 8 | Dark utility buttons, inline card imagery. |
| `md` | 12 | Inputs when not pill, nested cards, tooltips. |
| `tray` | 16 | Trays inside panels. |
| `lg` | 18 | Stat tiles, utility cards. |
| `xl` | 24 | Desktop panels, mobile action tiles, promo cards. |
| `xxl` | 28 | Mobile list cards, the glossy object card. |
| `sheet` | 38 | Glass sheets. |
| `device` | 48 | Phone frame preview only. |
| `pill` | 9999 | Buttons, chips, nav items, search, tab bar, toast, progress bars, avatars. |

### 5.2 Concentric rule

Inner radius = outer radius minus the gap between them.

- Panel 24 with 8px tray inset → tray 16 (`tray`). A tile inside that tray → 8 (`sm`).
- Concentric math applies when the gap is 12px or less. With a generous 24px panel padding, inner tiles use their own token (`lg` 18) and are not concentric.
- Mobile card 28 with 8px padding → inner rows are rectangles with hairline dividers, not rounded.
- Sheet 38 inset 8px from the screen edge → the device corner is 46–48.

### 5.3 Corner shape

Where supported, add `corner-shape: squircle` (continuous corners) to `xl`, `xxl`, `sheet` and the tab bar. It is a progressive enhancement. The layout must be correct without it.

### 5.4 Pill rule

Pill means "action or control". Buttons, chips, nav, search and the tab bar are pills. Large content panels are never pills. Do not mix pill with 11–12px rectangles inside the same control group.

---

## 6. Surfaces and elevation

### 6.1 The tonal stack

Depth comes from stepping tone, in this order:

```
Level 0  shell      #f5f5f7   page
Level 1  panel      #ffffff   groups of content
Level 2  tray       #f5f5f7   subgroup inside a panel
Level 3  tile       #ffffff   item inside a tray   (or parchment tile inside a white panel)
```

White on parchment on white. Do not go deeper than three levels. A fourth level means the layout needs restructuring, not another gray.

### 6.2 Shadow budget

There are **three** shadows in the system. Anything else is a bug.

| Name | Value | Where | Why |
|---|---|---|---|
| `product` | `3px 5px 30px rgba(0,0,0,0.22)` | A rendered object resting on a surface: the glossy card, a document preview, a device mockup. | Gives a physical thing weight. |
| `float` | `0 8px 32px rgba(0,0,0,0.10)` | Layers that float above content: tab bar, toast, popover, menu, command palette, bulk action bar. | Separates a floating layer from what it covers. |
| `sheet` | `0 -10px 40px rgba(0,0,0,0.14)` | Bottom sheets only (shadow falls upward). | Sheet rising over the page. |

The presentation `window` shadow (`0 24px 64px rgba(0,0,0,0.22)`) is for marketing mockups only, not product UI.

**Never** shadow: panels, trays, tiles, list cards, buttons, inputs, chips, nav, table rows, stat tiles, the ember tile. Those separate by tone and spacing.

### 6.3 Shadow decision

| Question | Answer |
|---|---|
| Does it float above scrolling content and can be dismissed? | Yes → `float` or `sheet`. |
| Is it a physical-looking object resting on a surface? | Yes → `product`. |
| Is it a normal piece of the page? | No shadow. Use tone. |
| Is it a text or a button? | No shadow, ever. |

### 6.4 Dark-object rim

Dark objects (glossy card, dark promo) add an inner rim so they read as polished glass: `inset 0 0 0 1px rgba(255,255,255,0.12), inset 0 1px 0 rgba(255,255,255,0.28)`. This is a highlight, not a drop shadow, and does not count against the budget.

---

## 7. Materials: glass

Glass is a functional layer for chrome that floats. It brings structure without stealing focus.

### 7.1 Three thicknesses

| Tier | Fill | Backdrop | Edge | Use |
|---|---|---|---|---|
| **Thin** | `rgba(255,255,255,0.55)` | `blur(20px) saturate(180%)` | 1px `rgba(255,255,255,0.75)` | Small round buttons floating over content (search, notifications, back). |
| **Regular** | `rgba(245,245,247,0.72)` | `blur(26px) saturate(180%)` | 1px top `rgba(255,255,255,0.65)`, bottom `rgba(0,0,0,0.06)` | Top bars, tab bar, toasts, popovers, bulk action bar. |
| **Thick** | `rgba(245,245,247,0.70)` | `blur(28px) saturate(190%)`, rising to `blur(44px)` as the sheet opens | same as regular | Bottom sheets, side drawers, command palette. |
| **Dark** (Specified) | `rgba(39,39,41,0.72)` | `blur(28px) saturate(180%)` | 1px `rgba(255,255,255,0.12)` | Layers over dark tiles and photography. |

Bigger surfaces read as thicker: more blur, deeper shadow.

### 7.2 Rules

- **Bright top edge.** Every glass layer has a 1px lighter top border. It reads as light catching the material.
- **Never stack light glass on light glass.** Legibility collapses. A popover over a glass bar becomes a solid white panel.
- **Color goes on a solid layer**, not on the translucent one. A selected tab indicator is a solid 78% white pill inside the glass, not a tinted glass.
- **Text over glass** is Ink at weight 600, with a small tracking bump at small sizes. Never flat mid-gray.
- **Scroll edge, not divider.** A bar over content is transparent at rest. As content scrolls beneath it, blur and a hairline fade in with scroll position (`--sc` from 0 to 1 over 48–56px). Do not draw a permanent 1px line.
- **Materialize, do not fade.** Glass surfaces enter by animating blur radius, scale (0.92 to 1) and opacity together over 320–420ms. A plain opacity fade looks cheap.
- **Dim to focus, separate to keep flow.** A modal sheet gets a scrim (`rgba(0,0,0,0.34)` scaled by sheet progress) and the page behind scales to 0.93, rounds its corners to 44px and shifts down 8px. A non-blocking panel (toast, popover) gets no scrim.

### 7.3 Fallbacks (mandatory)

```css
@media (prefers-reduced-transparency: reduce) {
  .glass { background: var(--color-parchment); backdrop-filter: none; }
}
@media (prefers-contrast: more) {
  .glass { background: var(--color-parchment); border-color: var(--color-ink-80); backdrop-filter: none; }
}
```

### 7.4 The glass recipe

```css
.glass {
  background: rgba(245, 245, 247, 0.72);
  -webkit-backdrop-filter: blur(26px) saturate(180%);
  backdrop-filter: blur(26px) saturate(180%);
  border: 1px solid rgba(255, 255, 255, 0.65);
  border-bottom-color: rgba(0, 0, 0, 0.06);
}
/* A bar that becomes glass as content passes under it. --sc is 0..1 from scrollTop / 56 */
.topbar::before {
  content: "";
  position: absolute; inset: 0; z-index: -1;
  background: rgba(245, 245, 247, calc(var(--sc) * 0.78));
  backdrop-filter: blur(calc(var(--sc) * 26px)) saturate(180%);
  border-bottom: 1px solid rgba(0, 0, 0, calc(var(--sc) * 0.08));
}
```

---

## 8. Components

Status: **B** = built, **S** = specified.

### 8.1 Choosing a card (the key decision)

Pick the card by what the content is. Do not pick by how it looks.

| Content | Use | Surface | Radius | Shadow | Status |
|---|---|---|---|---|---|
| A group of related content (a chart, a table, a list, a form) | **Panel** | white on shell | 24 (desktop), 28 (mobile) | none | B |
| A subgroup inside a panel (wallet list, filter strip, sub-metrics) | **Tray** | parchment in white | 16 | none | S |
| One number with its label and trend | **Stat tile** | parchment (neutral) | 18 | none | S |
| The one number the page is about | **Hero stat tile** | ember gradient | 18 | none | S |
| A thing the user holds or owns (a card, a device, a document preview) | **Object card** | graphite gradient, rim, tilt | 28 | `product` | B |
| Homogeneous rows (tasks, approvals, people, invoices) | **List card** | white, rows with inset dividers | 28 mobile, 24 desktop | none | B |
| Three to four quick actions | **Action tiles** | white on parchment | 24 | none | B |
| Something floating above content (menu, sheet, toast, bar) | **Glass layer** | glass tiers | per layer | `float` or `sheet` | B |
| A recommendation, upgrade or announcement | **Promo card** | `tile-1` dark | 24 | none (rim only) | B |
| A full-bleed marketing or onboarding band | **Tile** | alternating white, parchment, `tile-1` | 0 | none | B (desktop v1) |
| Dense records to scan and compare | **Table** (inside a panel) | white rows, parchment header | panel radius | none | S |

Do not nest panel inside panel. A panel contains trays, tiles and rows. A tray contains tiles. Tiles contain content.

### 8.2 Stat tile (S)

```
┌──────────────────────────────┐
│ Label                    (○) │  caption, ink-80. Optional 24px outline icon, top right
│                              │
│ $689,372          stat-lg    │  numeral, tabular, white on ember / ink on neutral
│ ↑ 5%   This month            │  delta chip + period caption (footnote, ink-60)
└──────────────────────────────┘
```

- 16px padding, radius 18, parchment fill, no border.
- The icon is a line glyph in a 24px circle with a 1px hairline ring. It is optional and decorative, so omit it when it adds nothing.
- Always show the **period** ("This month"). A number without a period is incomplete.
- Always pair a delta with an arrow and a chip. Never a bare colored number.

### 8.3 Hero stat tile (S)

The ember gradient tile carries the single most important number on the screen.

- One per viewport. Two ember tiles dilute both.
- Value in white at `stat-xl` (40px) or `stat-lg` (32px) minimum. Label, caption and delta in **Ink**, not white (contrast, section 2.5). The delta chip is white at 90% with `ember-text`.
- The icon ring uses a semi-transparent white outline.
- Hero is chosen by importance, not by money. For a project manager it may be "Tasks due this week" or "Capacity", not revenue.
- If every number is equally important, there is no hero, and all tiles are neutral.

### 8.4 When to use which stat treatment

| You have | Show it as | Notes |
|---|---|---|
| One KPI with a trend | **Stat tile** with delta chip | Max 4 per row, 2×2 grid inside a panel is the classic arrangement. |
| One KPI against a goal or limit | **Stat plus progress bar** | Pill track (hairline), fill ink for normal, ember for the highlighted or at-limit case. Caption "1,400 of 5,500". |
| A KPI that must dominate the screen | **Numeral-lg** hero at the top | Mobile pattern. Label above, delta pills below. |
| A KPI over time | **Sparkline in the tile** (small) or **bar chart in its own panel** (full) | Do not draw a full chart inside a stat tile. |
| Per-person or per-team load | **Capacity rows** | Avatar, name, role, percent, 6px pill bar. At 95% and over, bar turns white-on-dark or ember on light, with an "At limit" or "Over capacity" chip. |
| Delivered versus remaining | **Stacked bar: solid plus hatch** | Solid ink = delivered. Ember hatch = remaining or forecast. |
| A count that needs action | **Count badge** | Ink pill, white tabular number, 28px high. Used for unread, waiting approvals. |
| Status distribution | **Segmented bar** | Positive, caution, negative, neutral segments, each labeled. |
| A trend in a table cell | **Delta text with arrow** | 13px, semantic text color. No chip inside dense tables. |

Rules for every stat: label, value, period, delta. Value is tabular. Compare against something (last period, target) or it is trivia.

### 8.4b Delta chip (S)

Pill, 22px tall, 4px 8px padding, `label` type, arrow glyph. Positive: `positive` on `positive-tint`. Negative: `negative` on `negative-tint`. On the ember tile: `ember-text` on white 90%.

### 8.5 Buttons (B)

| Variant | Fill | Label | Radius | Height | Use |
|---|---|---|---|---|---|
| **Primary** | `primary` | white, 17/400 | pill | 44 | The one main action in a region. |
| **Ghost** | transparent, 1px `primary` | `primary` | pill | 44 | A second action beside a primary. |
| **Tray** | `parchment` | Ink, 14/600 | pill | 44 | Quiet secondary actions inside panels (Request, Reissue). |
| **Utility** | `ink` | white, 14/400 | `sm` 8 | 32 | Compact nav-level actions (Invite). Desktop only. |
| **Icon (glass)** | `glass-thin` | Ink glyph | pill | 44 | Floating over content. |
| **Icon (flat)** | transparent | Ink glyph | pill | 44 | In toolbars. Hover (pointer) is a parchment circle. |
| **Text** | none | `primary` | n/a | 44 hit area | In-row actions ("Undo", "Open project ›"). |

- One primary per region. If two buttons compete, the second is Ghost or Tray.
- Press: scale 0.95, 100ms ease-out, begins on pointer down. Large tiles scale 0.97, keypad keys 0.92. Reduced motion: no scale, opacity 0.8.
- Focus: 2px solid `primary-focus`, 2px offset.
- Disabled: fill `divider-soft`, label `ink-48`, no press feedback.
- Labels are verbs that say what happens: "Approve", "Log 2.5 hours", "Send money". Not "Submit", "OK", "Continue" unless it truly is that.
- No shadow on any button.

### 8.6 Chips and filters (B)

- Filter chip: white fill, 1px hairline, pill, 44px high, `caption`. Include a tabular count in `ink-80`.
- **Selected: 2px `primary-focus` ring** (reduce padding by 1px to keep size). Filter state is "something you set", so it uses blue.
- Group chips in a `role="group"` with `aria-pressed` on each.
- Horizontal scrolling chip rows bleed to the screen edge, no scrollbar.

### 8.7 Navigation (B and S)

| Pattern | Where | Active state |
|---|---|---|
| **Floating glass tab bar** (B) | Mobile, 4 destinations max | A solid 78% white pill slides under the active tab (spring 1.0 / 0.35). Active icon and label are `primary`. |
| **Sidebar** (S) | Desktop | **Ink pill** with white label. |
| **Top pill tabs** (S) | Page-level sections (Overview, Activity, Reports) | **Ink pill** inside a white pill container, 4px inset. |
| **Global nav** (B, desktop v1) | Black 44px bar | White labels, 12px. |

**Location is ink, state is blue.** "Where I am" uses the ink pill. "What I filtered" uses the blue ring. "What I can press" is blue text.

### 8.8 Lists and rows (B)

- Row min-height 64–76px, 12px vertical padding, 12px gap between parts.
- Anatomy: [unread dot 12px] [avatar or icon 44px, optional badge] [title + meta] [trailing time or action].
- Title `headline` (600). Once read, drop to 400. Meta `caption`, two lines max with line clamp.
- Dividers: 1px `divider-soft`, between rows only, never above the first or below the last.
- Avatar badge: 18px circle, `primary` fill, 2px white ring, glyph inside, bottom-right at -3px. It encodes the *kind* of item (approval, mention, blocker, update).
- Unread: 8px `primary` dot in a 12px column. Blue because "tap to open".
- **Swipe row** (B): trailing action revealed behind the row (Archive, 96px wide, `primary` fill). Open at -96px, commit past a projected -230px. Spring 0.8 / 0.3 with release velocity. Rubber-band past -140px. Opening one row closes others.

### 8.9 Tables (S, dense tier)

A table lives inside a white panel with a title row above it.

| Part | Spec |
|---|---|
| Header band | `parchment`, 40px, `data-head`, `ink-60`, top corners follow the panel radius. Sentence case. |
| Rows | White, 48px (44px dense), `data-cell`, `divider-soft` bottom border. |
| Numbers | Right-aligned, tabular. Identifiers left-aligned in `mono` or `data-strong`. |
| Selected row | `row-selected` fill, Ink-filled 14px checkbox with white check (radius 4). |
| Status | 6px dot plus 13px Ink label. **No filled status pills in tables.** |
| Row actions | "⋯" icon button, right edge, 36px. Appears at all times on touch, on hover or focus on pointer. |
| Sticky header | Becomes `glass-regular` when scrolled under the top bar. |
| Bulk actions | A floating glass bar appears bottom-center when 1+ rows are selected: "3 selected · Approve · Archive · Clear". Uses `float` shadow. |
| Pagination | Footer: "Showing 1–10 of 100" left, pill pager right. Current page is an Ink pill. |
| Empty | Centered `headline` plus one `caption` plus a primary button. |
| Below 640px | Rows become list cards. Status dot beside the title. |

Columns that matter most go first. Cap visible columns at 7. Anything else lives in a column picker, not a horizontal scroll.

### 8.10 Charts (S)

- **Series order:** ink first, ember second (only the highlighted or forecast series), blue third, gray fourth. Never more than 4.
- **Solid = actual. Hatch = remaining or forecast.** The hatch is `gradients.hatch` (2px ember stripes at 135° on `ember-tint`). This is the one decorative texture in the system, and it carries meaning.
- Bars: 4px top radius, 24–28px wide, 24px gap. Stacked bars put solid on the bottom, hatch on top.
- Grid: 1px `hairline`, dashed, horizontal only. Axis text 12px `ink-60`. No chart border.
- Legend: 8px dots plus `footnote` labels, top-right of the chart.
- Tooltip: regular glass, `float` shadow, 12px radius, appears on hover and tap, shows exact value and period.
- Every chart has a one-line title and a one-line description of the period. Never a chart without a unit.
- Do not use red/green as the only difference between series.

### 8.11 Statuses (B and S)

| Context | Treatment |
|---|---|
| Table rows | Dot plus Ink label. |
| Cards and tiles | Delta chip, or 10px dot plus semantic-text label ("● At risk"). |
| Mobile list rows | Dot plus label at the trailing edge. Shape also differs (outline ring for risk, solid for on-track) so it works without color. |
| Capacity | "At limit" and "Over capacity" chips, outlined white on dark, ember wash on light. |
| Stages of a flow | Segmented bar or stepper. |

Status always carries **text**. Color alone is never the signal.

### 8.12 Inputs (B and S)

- **Search:** white, 1px `rgba(0,0,0,0.08)`, pill, 44px high, 14px search glyph at 18px from the left, `body` text.
- **Text field:** white, 1px hairline, `md` 12px radius, 44px high (36px dense under pointer fine). Label above in `caption-strong`. Helper below in `caption`.
- **Validation:** inline, as the user types or on blur, never only on submit. Error text is `negative` with an icon, and the border becomes `negative-dot`. The message says what is wrong and how to fix it.
- **Keypad** (B): 3 × 4 grid, 64px keys, 34px tabular numerals, pill hit area, press scale 0.92 with a parchment flash. The "." key disables in minutes mode.
- **Segmented unit toggle:** a text button beside the amount ("Minutes", "Hours") with a swap glyph.

### 8.13 Feedback (B)

Four kinds, always:

| Kind | Component |
|---|---|
| Status | Inline dot, chip, count badge, progress. |
| Completion | **Glass toast.** Verb in past tense plus the object ("Logged 2h 30m to Mobile app 3.0") and an **Undo** text button. Auto-dismisses at about 3.5s. `role="status"`. |
| Warning | Inline banner in the panel, `caution-dot` icon plus text. |
| Error | Inline under the field, plus a summary banner for form-level errors. |

Undo beats "Are you sure?". Confirmation dialogs are only for irreversible actions (delete a project, remove a member).

### 8.14 Sheet (B)

A glass bottom sheet with three snap heights: **peek 654, half 430, full 70** (y from top of an 844 frame). The header is the grab area (draggable, tappable, keyboard focusable with `aria-expanded`). Content scrolls inside beneath it. The page behind pushes back (0.93 scale, 44px corners). The tab bar slides away at full.

### 8.15 Object card (B)

A glossy graphite card (`gradients.graphite`, 28px radius, rim, `product` shadow) with a moving sheen (`gradients.sheen`) and a soft radial highlight that follows the pointer. It tilts up to 9° on Y and 7° on X with springs (damping 1.0, response 0.25) and returns to rest on release. Content: mark (top left), status and stacked avatars (top right), title and metadata (bottom left), a ring progress (bottom right).

Use it for **one object per screen**: the active sprint, the primary account, the current project. Never for lists.

### 8.16 Promo and dark cards (B)

`tile-1` fill, rim, 24px radius, white title at `caption-strong`, supporting text in `body-muted`, one text link in `primary-on-dark`, a 44px dismiss. They carry announcements and upgrades, appear at most once per screen, and are always dismissible.

---

## 9. Decision tables

### 9.1 When to use orange

| Situation | Orange? | How |
|---|---|---|
| The single most important metric on the screen | Yes | Hero stat tile, ember gradient. |
| A progress or capacity fill that deserves attention | Yes | Flat `ember-500` on a hairline track. |
| The "remaining" or "forecast" part of a chart | Yes | Hatch. |
| The brand mark | Yes | `ember-500` tile, white glyph. |
| A label such as "At capacity" or "Needs attention" | Yes | `ember-wash` pill, `ember-text` label. |
| A button, a link, a toggle | **No** | Blue. |
| A status of success or failure | **No** | Green or red. |
| A second hero tile on the same screen | **No** | Make it neutral. |
| Large decorative backgrounds, section washes | **No** | Orange is a point of focus, not wallpaper. |
| Anything on glass | **No** | Keep glass neutral. |

### 9.2 When to use blue

Primary and ghost buttons, text links, text buttons, the filter ring, the focus ring, unread dots, the active tab on the mobile bar, avatar-badge fills, selected check indicators on dark. Nothing else.

### 9.3 When to use glass

| Layer | Glass? | Tier |
|---|---|---|
| Top bar (scrolled) | Yes | Regular |
| Tab bar | Yes | Regular |
| Bottom sheet, drawer, command palette | Yes | Thick |
| Toast, popover, tooltip, bulk bar | Yes | Regular |
| Floating round buttons over content | Yes | Thin |
| Panels, tiles, list cards, tables | **No** | Solid white or parchment |
| A layer over dark imagery | Yes | Dark |
| Whole page backgrounds | **No** | |

### 9.4 When to use dark surfaces

Object card (one per screen), promo card, the global nav, marketing rhythm bands, dark mode counterparts. Never dark panels in the middle of a light dashboard for decoration. A dark panel means "special object" or "different mode".

### 9.5 Which numeral size

| Where | Token |
|---|---|
| Entry screen amount (keypad) | `numeral-xl` |
| Mobile hero metric | `numeral-lg` |
| Desktop hero tile | `stat-xl` |
| Standard stat tile | `stat-lg` |
| Row or wallet figure | `stat-md` |
| Table figure | `data-strong` |

---

## 10. Motion

Motion is behavior, not decoration. Everything the user touches is a spring that can be interrupted.

### 10.1 Principles

1. **Respond on pointer down**, never wait for release.
2. **Track 1:1.** During a drag the element follows the pointer at the grab offset. Use Pointer Events with `setPointerCapture`.
3. **Always interruptible.** Animate from the **live on-screen value**, never the target. Never lock input during a transition.
4. **Hand off velocity.** Release velocity becomes the spring's initial velocity.
5. **Project momentum.** Choose the destination from `current + (v/1000) · 0.998 / (1 − 0.998)`, then snap to the nearest point.
6. **Rubber-band edges.** Resistance grows with distance past the bound. Never a hard stop.
7. **Symmetric paths.** What enters from a side exits to the same side. Menus originate from their trigger (`transform-origin`).
8. **Only `transform` and `opacity`** are animated (plus `backdrop-filter` on materializing glass).
9. **Feedback and sound/haptics on the causal event**, same frame. Haptics only for commit, snap, error (8–12ms).

### 10.2 Spring table

| Interaction | Damping | Response | Notes |
|---|---|---|---|
| Default UI (tab indicator, close row, reposition) | 1.0 | 0.35–0.4 | Critically damped, no overshoot. |
| Sheet settle after a flick | 0.8 | 0.3 | Bounce is allowed because the gesture carried momentum. |
| Swipe row settle or archive | 0.8 | 0.3 | Archive target is -420px. |
| Card tilt follow and return | 1.0 | 0.25 | Two independent springs (X and Y). |
| Tap-toggle sheet | 1.0 | 0.4 | No bounce, no momentum. |

Add bounce only when a flick preceded it. A menu that fades in does not bounce.

### 10.3 Timing

| Thing | Duration |
|---|---|
| Press scale | 100ms ease-out |
| Glass materialize (toast) | opacity 320ms `cubic-bezier(.2,.9,.3,1)`, transform 420ms `cubic-bezier(.2,1.2,.3,1)` |
| Scroll-linked effects | No timing, bound to scroll position |
| Auto-dismiss toast | about 3.5s |

Avoid CSS transitions and keyframes for anything gesture driven. Use a spring engine (Motion, or the ~40-line solver in section 14.4).

### 10.4 Gesture thresholds

| Gesture | Value |
|---|---|
| Drag hysteresis before committing | 6px (vertical sheet), 8px (horizontal swipe) |
| Velocity window | last 120ms of pointer positions |
| Sheet snap points | 70 / 430 / 654 px from the top |
| Swipe open | at -96px; commit-archive when projected end is beyond -230px |
| Tap | highlight on down, commit on up, cancel by dragging away |

### 10.5 Reduced motion and accessibility signals

```css
@media (prefers-reduced-motion: reduce) {
  .btn, .chip, .glass-btn { transition: none; }
  .btn:active, .chip:active { transform: none; opacity: .8; }
  .hero { transform: none; }              /* no tilt */
  .toast { transform: none; transition: opacity 200ms linear; }
}
```

In JS, when reduced motion is on, `run()` jumps to the target and fires the completion. Replace slides and springs with short cross-fades. Drop overshoot. Keep color and opacity changes that aid comprehension. Avoid full-viewport moving backgrounds and slow loops near 0.2 Hz.

---

## 11. Accessibility

- Touch targets 44 × 44px. On `pointer: fine` dense tier, 36px minimum.
- Text contrast 4.5:1, large text and UI shapes 3:1. Use section 2.5. Never `ink-48` for live text.
- Every interactive element is a real `<button>`, `<a href>` or `<input>` with a label. Icon-only controls carry `aria-label`. No `div` with a click handler.
- Focus is always visible: 2px `primary-focus`, 2px offset.
- Status uses text and shape in addition to color.
- Charts have a text summary and a data table alternative.
- Respect `prefers-reduced-motion`, `prefers-reduced-transparency`, `prefers-contrast`. Test all three.
- Sizes in `rem`. Layout survives 200% text zoom.
- Live regions (`role="status"`, `aria-live="polite"`) for toasts and amount displays.

---

## 12. Iconography and imagery

- Line icons, 1.5px stroke, rounded caps and joins, on a 16px grid. 22px in the tab bar, 20px in rows, 18px in top bar buttons, 14px in chips. `currentColor` only. Ink or `ink-80` on light, white on dark and ember.
- Icons sit in containers: 44px glass circle (top bar), 44px parchment circle (list row), 24px hairline ring (stat tile).
- Avatar: circle, 44px in lists, 28px in nav, 28px with 2px ring when stacked (-8px overlap).
- Product objects and photographs are the only imagery. No illustrations, no stock photography inside the app. Atmosphere comes from the object, not from CSS gradients.
- The only gradients in the product UI: `ember`, `graphite`, `sheen`, and the hatch pattern. Each has a role. No decorative gradient backgrounds.

---

## 13. Voice and copy

- Plain, specific, second person where it helps ("Waiting on you"). Sentence case.
- Name things by what the person recognizes: "Approvals", "Workload", "Projects", not "Modules" or "Home".
- Buttons say what happens. Toasts confirm what happened, with the object. Errors say what went wrong and how to fix it. No apologies, no "Oops".
- Greeting pattern: "Good morning, {first name}." followed by one line that states the situation ("2 projects are at risk and 3 approvals are waiting on you.").
- Empty states say what will appear here and how to add the first one.
- Numbers: thousands separators, currency symbol first, tabular. Dates "Oct 20" in lists, "Tuesday, October 20" in headers. Durations "2h 30m".

---

## 14. Builder quick start

### 14.1 Screen recipes

**Desktop Overview (S).** Shell `parchment`. Sidebar plus glass top bar. Greeting (`display`) with one situation line. Row 1 (12-col): hero panel with the amount or capacity numeral and actions (4 cols), 2×2 stat grid with one hero ember tile and three neutral (4 cols), main chart panel with solid plus hatch bars (4 cols). Row 2: list panel (workload or approvals, 4 cols), wide table panel (8 cols). Footer is parchment with dense link columns.

**Project list (S).** Filter chips plus search in one row. A 3-column card grid on desktop (panel cards: name, owner, status dot plus label, percent, thin progress bar, meta, "Open project ›"), or a dense table with a view toggle. Selected filter has the blue ring.

**Project detail (S).** Header: breadcrumb, `display` title, status, primary action. Top row: hero stat (progress or remaining work), 3 neutral stats (open tasks, people, due date). Body: tabs as Ink pill (Overview, Tasks, Timeline, Files). A task table in dense mode with bulk glass bar. Right column: activity list card.

**Mobile Today (B).** Transparent bar over parchment. Hero numeral with delta pills. Three action tiles. One object card with tilt. A Today list card. Glass approvals sheet with three snap heights. Floating glass tab bar.

**Log time (B).** White screen. Close glass button. Project chip. `numeral-xl` amount with unit. "= 2h 30m" equivalent with unit swap. Task row with "Use rest". Keypad. Primary "Log 2.5 hours" button. Glass toast with Undo.

**Inbox (B).** Large title collapsing into the glass bar. Filter chips with counts. Dismissible dark promo card. Today and Yesterday list cards. Swipe to archive with Undo toast.

### 14.2 Build checklist (run before you say done)

1. Every color, radius, shadow and size is a token. No stray hex.
2. Only weights 400 and 600. Tabular numerals on every figure.
3. Exactly one hero per screen: one big numeral, one ember tile.
4. Blue only on things you can press. No ember on buttons or links.
5. No shadow on panels, tiles, buttons or rows. Only `product`, `float`, `sheet`.
6. Glass only on floating layers, never stacked light on light, always with a top edge and fallbacks.
7. Radii are concentric. Pills only on controls.
8. Status has text and shape, not color alone.
9. 44px targets (36px dense on pointer fine). Visible focus.
10. Springs, not CSS transitions, for gestures. Reduced motion, transparency and contrast handled.
11. Empty, loading, error and long-text states exist.
12. Light and dark themes are both defined at token level (dark counterparts are Specified, use `tile-1/2/3` and `glass-dark`).

### 14.3 CSS custom properties

```css
:root {
  /* neutrals */
  --color-ink: #1d1d1f;  --color-ink-80: #333333;  --color-ink-60: #6e6e73;  --color-ink-48: #7a7a7a;
  --color-canvas: #ffffff;  --color-parchment: #f5f5f7;  --color-pearl: #fafafc;
  --color-hairline: #e0e0e0;  --color-divider: #f0f0f0;  --color-row-selected: #f0f0f0;
  --color-tile-1: #272729;  --color-tile-2: #2a2a2c;  --color-tile-3: #252527;
  --color-black: #000000;  --color-chip: #d2d2d7;  --color-on-dark: #ffffff;  --color-body-muted: #cccccc;

  /* interactive */
  --color-primary: #0066cc;  --color-primary-focus: #0071e3;  --color-primary-on-dark: #2997ff;
  --color-primary-wash: rgba(0, 102, 204, 0.10);

  /* ember */
  --color-ember-400: #ff8b4e;  --color-ember-500: #f0561f;  --color-ember-600: #e8501a;
  --color-ember-text: #c2410c;  --color-ember-tint: #f9cdb6;  --color-ember-wash: rgba(240, 86, 31, 0.10);

  /* status */
  --color-positive: #1e7b43;  --color-positive-dot: #2f9e55;  --color-positive-tint: #e3f4e8;
  --color-negative: #c62828;  --color-negative-dot: #e5484d;  --color-negative-tint: #fce9e9;
  --color-caution-dot: #f2a93b;

  /* gradients */
  --gradient-ember: linear-gradient(160deg, #ff8b4e 0%, #f0561f 55%, #e8501a 100%);
  --gradient-graphite: linear-gradient(135deg, #3d3d40 0%, #1d1d1f 36%, #0a0a0b 100%);
  --pattern-hatch: repeating-linear-gradient(135deg, #f0561f 0 2px, #f9cdb6 2px 4px);

  /* glass */
  --glass-thin: rgba(255, 255, 255, 0.55);
  --glass-regular: rgba(245, 245, 247, 0.72);
  --glass-thick: rgba(245, 245, 247, 0.70);
  --glass-dark: rgba(39, 39, 41, 0.72);
  --glass-edge-top: rgba(255, 255, 255, 0.65);
  --glass-edge-bottom: rgba(0, 0, 0, 0.06);
  --blur-thin: blur(20px) saturate(180%);
  --blur-regular: blur(26px) saturate(180%);
  --blur-thick: blur(28px) saturate(190%);

  /* type */
  --font-display: "SF Pro Display", -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif;
  --font-text: "SF Pro Text", -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif;

  /* radii */
  --radius-xs: 5px;  --radius-sm: 8px;  --radius-md: 12px;  --radius-tray: 16px;  --radius-lg: 18px;
  --radius-xl: 24px;  --radius-2xl: 28px;  --radius-sheet: 38px;  --radius-pill: 9999px;

  /* spacing */
  --space-1: 4px;  --space-2: 8px;  --space-3: 12px;  --space-4: 16px;  --space-5: 20px;
  --space-6: 24px;  --space-8: 32px;  --space-12: 48px;  --space-20: 80px;

  /* shadows (the entire budget) */
  --shadow-product: 3px 5px 30px 0 rgba(0, 0, 0, 0.22);
  --shadow-float: 0 8px 32px rgba(0, 0, 0, 0.10);
  --shadow-sheet: 0 -10px 40px rgba(0, 0, 0, 0.14);

  /* layout */
  --layout-sidebar: 264px;  --layout-sidebar-collapsed: 72px;  --layout-topbar: 56px;
  --layout-max: 1440px;  --layout-gutter: 20px;  --layout-tile-gap: 12px;
}

body {
  background: var(--color-parchment);
  color: var(--color-ink);
  font: 400 17px/1.47 var(--font-text);
  letter-spacing: -0.374px;
  font-feature-settings: "ss03";
  -webkit-font-smoothing: antialiased;
}
.num { font-variant-numeric: tabular-nums; }
.btn:active { transform: scale(0.95); transition: transform 100ms ease-out; }
```

### 14.4 Spring engine, projection and rubber band

```js
// Critically damped by default. Starts from the live value, inherits velocity.
function spring({ from, to, velocity = 0, damping = 1, response = 0.35, eps = 0.3, onUpdate, onDone }) {
  const w = (2 * Math.PI) / response, k = w * w, c = 2 * damping * w;
  let x = from - to, v = velocity, last = performance.now(), id;
  const step = (now) => {
    const dt = Math.min((now - last) / 1000, 0.034); last = now;
    const n = Math.max(1, Math.ceil(dt / 0.004)), h = dt / n;
    for (let i = 0; i < n; i++) { v += (-k * x - c * v) * h; x += v * h; }
    onUpdate(to + x);
    if (Math.abs(x) < eps && Math.abs(v) < eps * 20) { onUpdate(to); onDone && onDone(); return; }
    id = requestAnimationFrame(step);
  };
  id = requestAnimationFrame(step);
  return () => cancelAnimationFrame(id);   // call to interrupt, then start a new spring from the current value
}

const project = (v, d = 0.998) => (v / 1000) * d / (1 - d);              // v in px/s
const rubber = (o, dim, c = 0.55) => (o * dim * c) / (dim + c * Math.abs(o));
const nearest = (y, points) => points.reduce((a, b) => (Math.abs(b - y) < Math.abs(a - y) ? b : a));
// On release: target = nearest(y + project(releaseVelocity), [70, 430, 654]); spring({ from: y, to: target, velocity: releaseVelocity, damping: 0.8, response: 0.3 })
```

### 14.5 Tailwind v4

```css
@theme {
  --color-ink: #1d1d1f;  --color-ink-80: #333333;  --color-ink-60: #6e6e73;
  --color-canvas: #ffffff;  --color-parchment: #f5f5f7;  --color-hairline: #e0e0e0;
  --color-primary: #0066cc;  --color-primary-focus: #0071e3;
  --color-ember-500: #f0561f;  --color-ember-400: #ff8b4e;  --color-ember-text: #c2410c;  --color-ember-tint: #f9cdb6;
  --color-positive: #1e7b43;  --color-negative: #c62828;
  --font-display: "SF Pro Display", -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif;
  --font-sans: "SF Pro Text", -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif;
  --radius-md: 12px;  --radius-lg: 18px;  --radius-xl: 24px;  --radius-2xl: 28px;
  --shadow-product: 3px 5px 30px 0 rgba(0, 0, 0, 0.22);
  --shadow-float: 0 8px 32px rgba(0, 0, 0, 0.10);
  --shadow-sheet: 0 -10px 40px rgba(0, 0, 0, 0.14);
  --text-numeral-lg: 80px;  --text-stat-lg: 32px;  --text-headline: 17px;  --text-caption: 14px;  --text-data: 13px;
}
```

### 14.6 Prompts for an AI builder

Paste this file first, then ask for one component or screen at a time.

- "Build the Desktop Overview from DESIGN.md section 14.1. Use only tokens. One hero ember tile, three neutral stat tiles, a chart with solid and hatched bars, a workload list card, and a dense table in a panel. No shadows on panels."
- "Build a stat tile and a hero stat tile exactly as in 8.2 and 8.3. Show all four states: positive delta, negative delta, with progress, and loading."
- "Build the glass top bar from 7.4 that gains blur as the page scrolls, with fallbacks for reduced transparency and high contrast."
- "Build the bottom sheet from 8.14 with the spring engine in 14.4: three snap points, momentum projection, rubber-banding, grab-to-interrupt, tab bar sliding away."
- "Build the dense task table from 8.9 with selection, a floating glass bulk-action bar, status dots, and a card-list layout below 640px."
- "Audit this screen against the checklist in 14.2 and list each violation with the token that fixes it."

---

## 15. Do and Don't

### Do

- Stack white on parchment on white. Let tone do the separating.
- Give every screen one big number and one hero.
- Use blue for every pressable thing and nothing else.
- Use orange for exactly the thing that should be noticed, and make it scarce.
- Pair every delta with an arrow, a chip and a period.
- Use dot plus text for statuses. Add a shape difference as well as color.
- Put glass on floating layers only, with a bright top edge and accessible fallbacks.
- Press feedback on pointer down. Springs for everything touched. Hand off velocity.
- Keep radii concentric and pills for controls.
- Tabular numerals, always, for figures.
- Show undo after destructive-feeling actions instead of confirming first.

### Don't

- Don't add a shadow to a panel, tile, button, input or row.
- Don't use orange on buttons or links. Don't put two ember hero tiles on a screen.
- Don't use blue for decoration, charts, or non-interactive icons.
- Don't use weight 500 or 700, all caps labels, or one letter-spacing for every size.
- Don't use `ink-48` for text people must read.
- Don't use white small text on ember. Use Ink, or raise to 24px+.
- Don't stack glass on glass, or use glass for content panels.
- Don't use filled status pills inside tables.
- Don't use decorative gradients. Don't use illustration or emoji as icons.
- Don't use CSS transitions for gesture-driven motion, or lock input during an animation.
- Don't nest panel in panel. Don't go beyond three tonal levels.
- Don't use a hard divider under a bar. Use the scroll-edge blur.
- Don't show a number without its label, period and comparison.

---

## 16. Known gaps and next steps

- The orange accent, desktop shell, tables, charts, stat tiles and dark glass are **specified here but not yet drawn**. The three phone screens and the first desktop page are built in the neutral and blue palette and need an update pass to adopt ember and the management layer.
- Dark mode is specified through `tile-1/2/3`, `glass-dark` and the dark rim, but full dark counterparts of panels, trays and tables are not yet defined.
- Chart and table components are specified, not implemented. Validate the dense tier on a real 10,000-row dataset.
- Fonts: SF Pro cannot be loaded from the web off Apple devices. Inter is the fallback and slightly changes widths and tracking. Check line breaks in narrow tiles.
- `corner-shape: squircle` and `backdrop-filter` support varies. The layout must hold without either.
- Haptics (`navigator.vibrate`) are Android and some browsers only. Treat them as an enhancement.
